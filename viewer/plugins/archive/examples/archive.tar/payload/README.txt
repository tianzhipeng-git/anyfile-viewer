Anyfile archive metadata viewer example.
第二行是 Unicode 内容。
